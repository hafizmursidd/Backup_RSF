﻿Public Class ParameterDTO
    Public Property CPARAMETER_ID As String
    Public Property CPARAMETER_VALUE As String
End Class
