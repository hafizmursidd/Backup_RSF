Public Class LoginDTO
    Public Property DLAST_UPDATE_PSWD As String
    Public Property CCULTURE_ID As String
    Public Property CDATE_LONG_FORMAT As String
    Public Property CDATE_SHORT_FORMAT As String
    Public Property CTIME_LONG_FORMAT As String
    Public Property CTIME_SHORT_FORMAT As String
    Public Property CNUMBER_FORMAT As String
    Public Property CREPORT_CULTURE As String
    Public Property IDECIMAL_PLACES As Integer
    Public Property IROUNDING_PLACES As Integer
    Public Property CROUNDING_METHOD As String
    Public Property LENABLE_SAVE_CONFIRMATION As Boolean
    Public Property CLICENSE_MODE As String
    Public Property NLICENSEE As Integer

    Public Property CUSER_ID As String
    Public Property CUSER_PASSWORD As String
    Public Property CUSER_NAME As String
    Public Property CCOMPANY_ID As String
    Public Property CCOMPANY_NAME As String
End Class
