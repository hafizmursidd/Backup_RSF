﻿Public Class ParamDTO
    Public Property CCOMPANY_ID As String
    Public Property CUSER_ID As String
    Public Property CLANGUAGE_ID As String
    Public Property CMENU_ID As String
    Public Property CSUB_MENU_ID As String
    Public Property ILEVEL As Integer
    Public Property CMODUL_ID As String
End Class
