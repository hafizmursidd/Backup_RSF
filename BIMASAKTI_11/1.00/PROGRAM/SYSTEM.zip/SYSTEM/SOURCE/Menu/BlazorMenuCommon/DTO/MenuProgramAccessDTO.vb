﻿Public Class MenuProgramAccessDTO
    Public Property CCOMPANY_ID As String
    Public Property CMENU_ID As String
    Public Property CPROGRAM_ID As String
    Public Property CACCESS_ID As String
    Public Property CMENU_NAME As String
    Public Property CPROGRAM_NAME As String
    Public Property CTOOL_TIP As String
End Class
