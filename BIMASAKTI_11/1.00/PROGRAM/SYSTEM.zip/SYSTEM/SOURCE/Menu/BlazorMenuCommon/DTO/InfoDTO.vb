﻿Public Class InfoDTO
    Public Property InfoName As String
    Public Property InfoDesc As String
End Class
