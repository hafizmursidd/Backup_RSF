﻿Public Class UserCompanyDTO
    Property CUSER_ID As String
    Property CCOMPANY_ID As String
    Property LCAN_BROADCAST As Boolean
End Class
