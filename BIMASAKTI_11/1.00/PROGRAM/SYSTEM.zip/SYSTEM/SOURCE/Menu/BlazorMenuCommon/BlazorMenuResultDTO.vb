﻿Imports R_APICommonDTO

Public Class BlazorMenuResultDTO (Of T)
    Inherits R_APIResultBaseDTO

    Public Property Data As T
End Class

Public Class BlazorMenuResultDTO
    Inherits R_APIResultBaseDTO
End Class
