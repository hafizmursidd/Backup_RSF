﻿using R_BlazorFrontEnd.Interfaces;

namespace BlazorClientHelper;

public interface IClientHelper : R_IGlobalVarInitiator
{
}