﻿using Microsoft.AspNetCore.Components;

namespace BlazorMenu.Shared
{
    public partial class MainLayout : LayoutComponentBase
    {

    }
}
